import 'package:flutter_test/flutter_test.dart';
import 'package:shop/features/orders/model/order_model.dart';
import 'package:shop/features/products/model/product_model.dart';

void main() {
  test('Product parses Laravel product JSON', () {
    final product = Product.fromJson({
      'id': 7,
      'name': 'Phone',
      'description': 'Android phone',
      'price': '350.00',
      'stock': 4,
      'category': 'Electronics',
      'image': 'products/phone.jpg',
    });
    expect(product.id, 7);
    expect(product.price, 350.0);
    expect(product.category, 'Electronics');
  });

  test('Order reads total_price from Laravel response', () {
    final order = Order.fromJson({
      'id': 3,
      'user_id': 2,
      'status': 'pending',
      'total_price': '700.00',
      'items': [],
    });
    expect(order.totalPrice, 700.0);
  });
}
