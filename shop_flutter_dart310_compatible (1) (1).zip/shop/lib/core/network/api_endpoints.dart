class ApiEndpoints {
  // Flutter desktop/web on the same computer as Docker: use the published host port.
  // Android emulator: run with --dart-define=API_BASE_URL=http://10.0.2.2:8000/api
  // Physical phone: use the computer's LAN IP, e.g. http://192.168.1.10:8000/api
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://127.0.0.1:8000/api',
  );

  static const String register = '/register';
  static const String login = '/login';
  static const String profile = '/profile';
  static const String products = '/products';
  static String productDetail(int id) => '/products/$id';
  static const String orders = '/orders';
  static String orderDetail(int id) => '/orders/$id';
  static const String notifications = '/notifications';
  static String markNotificationRead(String id) => '/notifications/$id/read';

  static String get serverBaseUrl {
    final uri = Uri.parse(baseUrl);
    return '${uri.scheme}://${uri.authority}';
  }

  static String? imageUrl(String? path) {
    if (path == null || path.trim().isEmpty) return null;
    final value = path.trim();
    if (value.startsWith('http://') || value.startsWith('https://')) return value;
    final normalized = value.startsWith('/') ? value : '/storage/$value';
    return '$serverBaseUrl$normalized';
  }
}
