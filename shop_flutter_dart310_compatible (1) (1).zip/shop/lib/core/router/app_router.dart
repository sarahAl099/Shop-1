import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/auth/data/auth_repository.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/products/presentation/products_screen.dart';

class AppRouter extends ConsumerStatefulWidget {
  const AppRouter({super.key});
  @override ConsumerState<AppRouter> createState() => _AppRouterState();
}
class _AppRouterState extends ConsumerState<AppRouter> {
  bool _checking = true;
  @override void initState() { super.initState(); _restoreSession(); }
  Future<void> _restoreSession() async {
    try {
      final token = await ref.read(secureStorageProvider).getToken();
      if (token != null && token.isNotEmpty) {
        final user = await ref.read(authRepositoryProvider).fetchProfile();
        ref.read(currentUserProvider.notifier).state = user;
        ref.read(authStateProvider.notifier).state = true;
      }
    } catch (_) {
      await ref.read(secureStorageProvider).clearToken();
    } finally { if (mounted) setState(() => _checking = false); }
  }
  @override Widget build(BuildContext context) {
    if (_checking) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return ref.watch(authStateProvider) ? const ProductsScreen() : const LoginScreen();
  }
}
