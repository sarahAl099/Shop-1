import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../../auth/data/auth_repository.dart';
import '../model/order_model.dart';
final orderRepositoryProvider = Provider((ref) => OrderRepository(ref.watch(dioClientProvider)));
class OrderRepository {
  OrderRepository(this._client);
  final DioClient _client;
  Future<List<Order>> getOrders() async {
    final List<Order> orders = [];
    var page = 1;
    var lastPage = 1;
    do {
      final response = await _client.dio.get(ApiEndpoints.orders, queryParameters: {'page': page});
      final body = response.data;
      final List data = body is Map && body['data'] is List ? body['data'] as List : body as List;
      orders.addAll(data.map((e) => Order.fromJson(Map<String, dynamic>.from(e))));
      if (body is Map) lastPage = int.tryParse((body['last_page'] ?? page).toString()) ?? page;
      page++;
    } while (page <= lastPage);
    return orders;
  }
  Future<Order> getOrder(int id) async {
    final response = await _client.dio.get(ApiEndpoints.orderDetail(id));
    return Order.fromJson(Map<String, dynamic>.from(response.data['order'] ?? response.data));
  }
  Future<void> createOrder(List<OrderItemModel> items) async {
    await _client.dio.post(ApiEndpoints.orders, data: {'items': items.map((e) => e.toJson()).toList()});
  }
}
final ordersProvider = FutureProvider<List<Order>>((ref) => ref.watch(orderRepositoryProvider).getOrders());
