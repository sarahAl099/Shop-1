class OrderItemModel {
  final int productId;
  final int quantity;
  OrderItemModel({required this.productId, required this.quantity});
  Map<String, dynamic> toJson() => {'product_id': productId, 'quantity': quantity};
}
class Order {
  final int id;
  final int userId;
  final String status;
  final double totalPrice;
  final List<dynamic> items;
  Order({required this.id, required this.userId, required this.status, required this.totalPrice, required this.items});
  factory Order.fromJson(Map<String, dynamic> json) => Order(
    id: int.parse(json['id'].toString()), userId: int.tryParse((json['user_id'] ?? 0).toString()) ?? 0,
    status: json['status']?.toString() ?? 'pending',
    // Laravel Order model returns total_price; total_amount is accepted only for older API variants.
    totalPrice: double.tryParse((json['total_price'] ?? json['total_amount'] ?? 0).toString()) ?? 0,
    items: json['items'] is List ? json['items'] as List : const [],
  );
}
