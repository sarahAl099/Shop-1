import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/order_repository.dart';

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ordersAsync = ref.watch(ordersProvider);
    return Scaffold(body: ordersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => _ErrorView(message: e.toString(), onRetry: () => ref.invalidate(ordersProvider)),
        data: (orders) => orders.isEmpty ? const Center(child: Text('لا توجد طلبات حتى الآن')) : RefreshIndicator(onRefresh: () async => ref.invalidate(ordersProvider), child: ListView.separated(padding: const EdgeInsets.all(12), itemCount: orders.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (context, i) {
          final order = orders[i];
          return Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.receipt_long)), title: Text('طلب رقم #${order.id}'), subtitle: Text('الحالة: ${order.status} • عدد المنتجات: ${order.items.length}'), trailing: Text('${order.totalPrice.toStringAsFixed(2)}'), onTap: () async { try { final detail = await ref.read(orderRepositoryProvider).getOrder(order.id); if (!context.mounted) return; showDialog(context: context, builder: (_) => AlertDialog(title: Text('تفاصيل الطلب #${detail.id}'), content: SizedBox(width: 360, child: detail.items.isEmpty ? const Text('لا توجد تفاصيل') : ListView(shrinkWrap: true, children: detail.items.map((raw) { final item = Map<String, dynamic>.from(raw); final product = item['product'] is Map ? Map<String, dynamic>.from(item['product']) : <String, dynamic>{}; return ListTile(title: Text(product['name']?.toString() ?? 'منتج #${item['product_id']}'), subtitle: Text('الكمية: ${item['quantity'] ?? 1}'), trailing: Text('${item['price'] ?? product['price'] ?? ''}')); }).toList())), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))])); } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); } }));
        })),
      ));
  }
}
class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message; final VoidCallback onRetry;
  @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off, size: 44), const SizedBox(height: 8), const Text('تعذر تحميل البيانات'), Text(message, textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: onRetry, child: const Text('إعادة المحاولة'))])));
}
