import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../../auth/data/auth_repository.dart';
import '../model/notification_model.dart';
final notificationRepositoryProvider = Provider((ref) => NotificationRepository(ref.watch(dioClientProvider)));
class NotificationRepository {
  NotificationRepository(this._client);
  final DioClient _client;
  Future<List<AppNotification>> getNotifications() async {
    final List<AppNotification> notifications = [];
    var page = 1;
    var lastPage = 1;
    do {
      final response = await _client.dio.get(ApiEndpoints.notifications, queryParameters: {'page': page});
      final body = response.data;
      final List data = body is Map && body['data'] is List ? body['data'] as List : body as List;
      notifications.addAll(data.map((e) => AppNotification.fromJson(Map<String, dynamic>.from(e))));
      if (body is Map) lastPage = int.tryParse((body['last_page'] ?? page).toString()) ?? page;
      page++;
    } while (page <= lastPage);
    return notifications;
  }
  Future<void> markAsRead(String id) async => _client.dio.patch(ApiEndpoints.markNotificationRead(id));
}
final notificationsProvider = FutureProvider<List<AppNotification>>((ref) => ref.watch(notificationRepositoryProvider).getNotifications());
