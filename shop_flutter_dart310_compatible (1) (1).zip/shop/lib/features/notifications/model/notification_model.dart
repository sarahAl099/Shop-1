class AppNotification {
  final String id;
  final String? title;
  final String? body;
  final DateTime? readAt;
  final DateTime? createdAt;
  AppNotification({required this.id, this.title, this.body, this.readAt, this.createdAt});
  factory AppNotification.fromJson(Map<String, dynamic> json) {
    final data = json['data'] is Map ? Map<String, dynamic>.from(json['data']) : <String, dynamic>{};
    return AppNotification(
      id: json['id'].toString(), title: (data['title'] ?? json['type'] ?? 'إشعار').toString(),
      body: (data['message'] ?? data['body'] ?? data['total_price']?.toString() ?? '').toString(),
      readAt: json['read_at'] == null ? null : DateTime.tryParse(json['read_at'].toString()),
      createdAt: json['created_at'] == null ? null : DateTime.tryParse(json['created_at'].toString()),
    );
  }
}
