import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/notification_repository.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notificationsAsync = ref.watch(notificationsProvider);
    return Scaffold(body: notificationsAsync.when(loading: () => const Center(child: CircularProgressIndicator()), error: (e, _) => Center(child: Text('تعذر تحميل الإشعارات: $e')), data: (items) => items.isEmpty ? const Center(child: Text('لا توجد إشعارات')) : RefreshIndicator(onRefresh: () async => ref.invalidate(notificationsProvider), child: ListView.separated(padding: const EdgeInsets.all(12), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 6), itemBuilder: (context, i) {
        final item = items[i];
        return Card(child: ListTile(leading: Icon(item.readAt == null ? Icons.notifications_active : Icons.notifications_none, color: item.readAt == null ? Colors.teal : null), title: Text(item.title ?? 'إشعار'), subtitle: Text('${item.body ?? ''}\n${item.createdAt?.toLocal().toString().substring(0, 16) ?? ''}'), isThreeLine: true, trailing: item.readAt == null ? IconButton(tooltip: 'تحديد كمقروء', icon: const Icon(Icons.mark_email_read_outlined), onPressed: () async { try { await ref.read(notificationRepositoryProvider).markAsRead(item.id); ref.invalidate(notificationsProvider); } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); } }) : const Icon(Icons.check_circle_outline)));
      }))),
    );
  }
}
