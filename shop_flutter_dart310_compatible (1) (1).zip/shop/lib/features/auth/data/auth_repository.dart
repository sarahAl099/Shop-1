import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/network/dio_client.dart';
import '../../../core/network/api_endpoints.dart';
import '../../../core/storage/secure_storage.dart';

final secureStorageProvider = Provider((ref) => SecureStorage());
final dioClientProvider = Provider((ref) => DioClient(storage: ref.watch(secureStorageProvider)));
final authRepositoryProvider = Provider((ref) => AuthRepository(
  ref.watch(dioClientProvider), ref.watch(secureStorageProvider)));
final authStateProvider = StateProvider<bool>((ref) => false);
final currentUserProvider = StateProvider<Map<String, dynamic>?>((ref) => null);

class AuthRepository {
  AuthRepository(this._client, this._storage);
  final DioClient _client;
  final SecureStorage _storage;

  Future<void> register({required String name, required String email,
    required String password, required String passwordConfirmation}) async {
    await _client.dio.post(ApiEndpoints.register, data: {
      'name': name,
      'email': email,
      'password': password,
      'password_confirmation': passwordConfirmation,
    });
  }

  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    final response = await _client.dio.post(ApiEndpoints.login, data: {
      'email': email, 'password': password,
    });
    final token = response.data['access_token']?.toString();
    if (token == null || token.isEmpty) throw Exception('لم يرجع الخادم access_token');
    await _storage.saveToken(token);
    return fetchProfile();
  }

  Future<Map<String, dynamic>> fetchProfile() async {
    final response = await _client.dio.get(ApiEndpoints.profile);
    final user = Map<String, dynamic>.from(response.data['user'] ?? response.data);
    return user;
  }

  Future<void> logout() => _storage.clearToken();
}

String apiErrorMessage(Object error) {
  // Convert Laravel validation/auth errors into readable Arabic messages.
  try {
    final dynamic e = error;
    final data = e.response?.data;
    if (data is Map) {
      if (data['errors'] is Map) {
        final errors = data['errors'] as Map;
        final first = errors.values.first;
        if (first is List && first.isNotEmpty) return first.first.toString();
      }
      if (data['message'] != null) return data['message'].toString();
    }
    if (e.type.toString().contains('connection')) {
      return 'تعذر الاتصال بالخادم. تأكد من تشغيل Laravel وDocker ومن عنوان API.';
    }
  } catch (_) {}
  return error.toString();
}
