import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/auth_repository.dart';
import 'register_screen.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hide = true;

  Future<void> _login() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final user = await ref.read(authRepositoryProvider).login(
        email: _email.text.trim(), password: _password.text);
      ref.read(currentUserProvider.notifier).state = user;
      ref.read(authStateProvider.notifier).state = true;
    } catch (e) {
      if (mounted) _message(apiErrorMessage(e));
    } finally { if (mounted) setState(() => _busy = false); }
  }
  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440),
      child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Card(
        child: Padding(padding: const EdgeInsets.all(24), child: Form(key: _form, child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Icon(Icons.shopping_bag_outlined, size: 64, color: Colors.teal),
            const SizedBox(height: 12), Text('متجر إلكتروني', textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8), const Text('تسجيل الدخول', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            TextFormField(controller: _email, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder()),
              validator: (v) => v == null || !v.contains('@') ? 'أدخل بريداً إلكترونياً صحيحاً' : null),
            const SizedBox(height: 14),
            TextFormField(controller: _password, obscureText: _hide,
              decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), border: const OutlineInputBorder(),
                suffixIcon: IconButton(onPressed: () => setState(() => _hide = !_hide), icon: Icon(_hide ? Icons.visibility : Icons.visibility_off))),
              validator: (v) => v == null || v.isEmpty ? 'أدخل كلمة المرور' : null),
            const SizedBox(height: 20),
            FilledButton(onPressed: _busy ? null : _login, child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('دخول')),
            TextButton(onPressed: _busy ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())), child: const Text('ليس لديك حساب؟ إنشاء حساب')),
          ],
        ))),
      )))),
  );
}
