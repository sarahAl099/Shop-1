import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/auth_repository.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});
  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}
class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _busy = false;
  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final repo = ref.read(authRepositoryProvider);
      await repo.register(name: _name.text.trim(), email: _email.text.trim(), password: _password.text, passwordConfirmation: _confirm.text);
      final user = await repo.login(email: _email.text.trim(), password: _password.text);
      ref.read(currentUserProvider.notifier).state = user;
      ref.read(authStateProvider.notifier).state = true;
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiErrorMessage(e))));
    } finally { if (mounted) setState(() => _busy = false); }
  }
  @override
  void dispose() { _name.dispose(); _email.dispose(); _password.dispose(); _confirm.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('إنشاء حساب')),
    body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 480), child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Form(key: _form, child: Column(children: [
      TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'الاسم مطلوب' : null),
      const SizedBox(height: 12), TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', border: OutlineInputBorder()), validator: (v) => v == null || !v.contains('@') ? 'البريد غير صحيح' : null),
      const SizedBox(height: 12), TextFormField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور (8 أحرف على الأقل)', border: OutlineInputBorder()), validator: (v) => v == null || v.length < 8 ? 'كلمة المرور يجب ألا تقل عن 8 أحرف' : null),
      const SizedBox(height: 12), TextFormField(controller: _confirm, obscureText: true, decoration: const InputDecoration(labelText: 'تأكيد كلمة المرور', border: OutlineInputBorder()), validator: (v) => v != _password.text ? 'كلمتا المرور غير متطابقتين' : null),
      const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: _busy ? null : _submit, child: _busy ? const CircularProgressIndicator() : const Text('إنشاء الحساب'))),
    ]))))));
}
