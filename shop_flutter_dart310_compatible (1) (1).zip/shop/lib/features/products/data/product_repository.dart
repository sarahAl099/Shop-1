import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../model/product_model.dart';

final productRepositoryProvider = Provider((ref) => ProductRepository(ref.watch(dioClientProvider)));
class ProductRepository {
  ProductRepository(this._client);
  final DioClient _client;
  Future<List<Product>> getProducts({String? category, String? search}) async {
    List<Product> products = [];
    var page = 1;
    var lastPage = 1;
    do {
      final response = await _client.dio.get(ApiEndpoints.products, queryParameters: {
        if (category != null && category.isNotEmpty) 'category': category,
        'page': page,
      });
      final body = response.data;
      final List data = body is Map && body['data'] is List ? body['data'] as List : body as List;
      products.addAll(data.map((e) => Product.fromJson(Map<String, dynamic>.from(e))));
      if (body is Map) lastPage = int.tryParse((body['last_page'] ?? page).toString()) ?? page;
      page++;
    } while (page <= lastPage);
    if (search != null && search.trim().isNotEmpty) {
      final term = search.toLowerCase();
      products = products.where((p) => p.name.toLowerCase().contains(term) || p.category.toLowerCase().contains(term)).toList();
    }
    return products;
  }
  Future<void> createProduct({required String name, required String description, required String price, required String stock, required String category, String? imagePath}) async {
    final form = FormData.fromMap({
      'name': name, 'description': description, 'price': price, 'stock': stock, 'category': category,
      if (imagePath != null) 'image': await MultipartFile.fromFile(imagePath),
    });
    await _client.dio.post(ApiEndpoints.products, data: form, options: Options(contentType: 'multipart/form-data'));
  }
  Future<void> updateProduct(int id, {required String name, required String description, required String price, required String stock, required String category, String? imagePath}) async {
    final form = FormData.fromMap({
      '_method': 'PUT', 'name': name, 'description': description, 'price': price, 'stock': stock, 'category': category,
      if (imagePath != null) 'image': await MultipartFile.fromFile(imagePath),
    });
    await _client.dio.post(ApiEndpoints.productDetail(id), data: form, options: Options(contentType: 'multipart/form-data'));
  }
  Future<void> deleteProduct(int id) async => _client.dio.delete(ApiEndpoints.productDetail(id));
}
final productListProvider = FutureProvider.family<List<Product>, String?>((ref, category) => ref.watch(productRepositoryProvider).getProducts(category: category));
