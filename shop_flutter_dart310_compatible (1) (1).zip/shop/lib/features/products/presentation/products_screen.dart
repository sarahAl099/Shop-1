import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../../auth/data/auth_repository.dart';
import '../../../orders/data/order_repository.dart';
import '../../../orders/model/order_model.dart';
import '../../../orders/presentation/orders_screen.dart';
import '../../../notifications/presentation/notifications_screen.dart';
import '../data/product_repository.dart';
import '../model/product_model.dart';
import 'product_form_screen.dart';

class ProductsScreen extends ConsumerStatefulWidget {
  const ProductsScreen({super.key});
  @override ConsumerState<ProductsScreen> createState() => _ProductsScreenState();
}
class _ProductsScreenState extends ConsumerState<ProductsScreen> {
  int _tab = 0;
  String? _category;
  String _search = '';
  final Map<int, int> _cart = {};

  bool get _isAdmin {
    final user = ref.read(currentUserProvider);
    return user?['role']?.toString().toLowerCase() == 'admin';
  }
  int get _cartCount => _cart.values.fold(0, (a, b) => a + b);

  Future<void> _logout() async {
    await ref.read(authRepositoryProvider).logout();
    ref.read(currentUserProvider.notifier).state = null;
    ref.read(authStateProvider.notifier).state = false;
  }
  Future<void> _checkout() async {
    if (_cart.isEmpty) return;
    try {
      await ref.read(orderRepositoryProvider).createOrder(_cart.entries.map((e) => OrderItemModel(productId: e.key, quantity: e.value)).toList());
      setState(() => _cart.clear());
      ref.invalidate(ordersProvider); ref.invalidate(productListProvider);
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء الطلب بنجاح'))); setState(() => _tab = 1); }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiErrorMessage(e))));
    }
  }
  Future<void> _openProductForm([Product? product]) async {
    final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: product)));
    if (changed == true) ref.invalidate(productListProvider);
  }
  Future<void> _deleteProduct(Product product) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('حذف المنتج'), content: Text('هل تريد حذف "${product.name}"؟'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))]));
    if (ok != true) return;
    try { await ref.read(productRepositoryProvider).deleteProduct(product.id); ref.invalidate(productListProvider); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف المنتج'))); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiErrorMessage(e)))); }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildProducts(),
      const OrdersScreen(),
      const NotificationsScreen(),
      _buildCart(),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(['المتجر الإلكتروني', 'طلباتي', 'الإشعارات', 'سلة المشتريات'][_tab]), actions: [
        if (_tab == 0) IconButton(tooltip: 'تحديث', onPressed: () => ref.invalidate(productListProvider), icon: const Icon(Icons.refresh)),
        if (_tab == 1) IconButton(tooltip: 'تحديث', onPressed: () => ref.invalidate(ordersProvider), icon: const Icon(Icons.refresh)),
        if (_tab == 2) IconButton(tooltip: 'تحديث', onPressed: () => ref.invalidate(notificationsProvider), icon: const Icon(Icons.refresh)),
        if (_tab == 0 && _isAdmin) IconButton(tooltip: 'إضافة منتج', onPressed: () => _openProductForm(), icon: const Icon(Icons.add_box_outlined)),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'logout') _logout(); else if (v == 'profile') _showProfile(); }, itemBuilder: (_) => const [PopupMenuItem(value: 'profile', child: Text('حسابي')), PopupMenuItem(value: 'logout', child: Text('تسجيل الخروج'))]),
      ]),
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i), destinations: [
        const NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'المنتجات'),
        const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'طلباتي'),
        const NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'الإشعارات'),
        NavigationDestination(icon: Badge(isLabelVisible: _cartCount > 0, label: Text('$_cartCount'), child: const Icon(Icons.shopping_cart_outlined)), selectedIcon: Badge(isLabelVisible: _cartCount > 0, label: Text('$_cartCount'), child: const Icon(Icons.shopping_cart)), label: 'السلة'),
      ]),
    );
  }

  Widget _buildProducts() {
    final productsAsync = ref.watch(productListProvider(_category));
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث عن منتج أو تصنيف', border: OutlineInputBorder()), onChanged: (v) => setState(() => _search = v))),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), child: Row(children: [const Text('التصنيف: '), const SizedBox(width: 8), DropdownButton<String?>(value: _category, hint: const Text('كل التصنيفات'), items: [const DropdownMenuItem<String?>(value: null, child: Text('الكل')), ...['Electronics', 'Clothing', 'Home', 'Books'].map((c) => DropdownMenuItem<String?>(value: c, child: Text(c)))], onChanged: (v) => setState(() => _category = v)), const Spacer(), IconButton(onPressed: () => ref.invalidate(productListProvider), icon: const Icon(Icons.refresh))])),
      Expanded(child: productsAsync.when(loading: () => const Center(child: CircularProgressIndicator()), error: (e, _) => Center(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.wifi_off, size: 42), const SizedBox(height: 8), const Text('تعذر الاتصال بالخادم'), Text(apiErrorMessage(e), textAlign: TextAlign.center), const SizedBox(height: 8), FilledButton(onPressed: () => ref.invalidate(productListProvider), child: const Text('إعادة المحاولة'))]))), data: (products) {
        final shown = products.where((p) => _search.isEmpty || p.name.toLowerCase().contains(_search.toLowerCase()) || p.category.toLowerCase().contains(_search.toLowerCase())).toList();
        if (shown.isEmpty) return const Center(child: Text('لا توجد منتجات مطابقة'));
        return RefreshIndicator(onRefresh: () async => ref.invalidate(productListProvider), child: LayoutBuilder(builder: (context, constraints) {
          final columns = constraints.maxWidth > 900 ? 4 : constraints.maxWidth > 600 ? 3 : 2;
          return GridView.builder(padding: const EdgeInsets.all(10), gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: columns, childAspectRatio: .69, crossAxisSpacing: 10, mainAxisSpacing: 10), itemCount: shown.length, itemBuilder: (context, i) => _productCard(shown[i]));
        }));
      })),
    ]);
  }

  Widget _productCard(Product p) {
    final image = ApiEndpoints.imageUrl(p.image);
    return Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Expanded(child: image == null ? Container(color: Colors.teal.withValues(alpha: .08), child: const Icon(Icons.shopping_bag_outlined, size: 56)) : Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.teal.withValues(alpha: .08), child: const Icon(Icons.image_not_supported_outlined, size: 48)))),
      Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 4), child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold))),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text(p.category, maxLines: 1, style: Theme.of(context).textTheme.bodySmall)),
      Padding(padding: const EdgeInsets.fromLTRB(10, 4, 10, 0), child: Text('${p.price.toStringAsFixed(2)}', style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold))),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('المخزون: ${p.stock}', style: Theme.of(context).textTheme.bodySmall)),
      if (_isAdmin) Row(children: [IconButton(tooltip: 'تعديل', onPressed: () => _openProductForm(p), icon: const Icon(Icons.edit_outlined, size: 20)), IconButton(tooltip: 'حذف', onPressed: () => _deleteProduct(p), icon: const Icon(Icons.delete_outline, size: 20))]),
      Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: FilledButton.tonal(onPressed: p.stock < 1 ? null : () { setState(() { final current = _cart[p.id] ?? 0; if (current < p.stock) _cart[p.id] = current + 1; }); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('أضيف ${p.name} إلى السلة'), duration: const Duration(milliseconds: 900))); }, child: const Text('أضف إلى السلة'))),
    ]));
  }

  Widget _buildCart() {
    if (_cart.isEmpty) return const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.remove_shopping_cart_outlined, size: 54), SizedBox(height: 10), Text('السلة فارغة')]));
    final productsAsync = ref.watch(productListProvider(null));
    return productsAsync.when(loading: () => const Center(child: CircularProgressIndicator()), error: (e, _) => Center(child: Text(apiErrorMessage(e))), data: (products) {
      final byId = {for (final p in products) p.id: p};
      final entries = _cart.entries.toList();
      final total = entries.fold<double>(0, (sum, e) => sum + (byId[e.key]?.price ?? 0) * e.value);
      return Column(children: [Expanded(child: ListView.builder(itemCount: entries.length, itemBuilder: (_, i) { final e = entries[i]; final p = byId[e.key]; if (p == null) return const SizedBox.shrink(); return ListTile(title: Text(p.name), subtitle: Text('${p.price.toStringAsFixed(2)} × ${e.value}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => setState(() { if (e.value <= 1) { _cart.remove(e.key); } else { _cart[e.key] = e.value - 1; } }), icon: const Icon(Icons.remove_circle_outline)), Text('${e.value}'), IconButton(onPressed: () => setState(() { if (e.value < p.stock) _cart[e.key] = e.value + 1; }), icon: const Icon(Icons.add_circle_outline)), IconButton(onPressed: () => setState(() => _cart.remove(e.key)), icon: const Icon(Icons.delete_outline))])); })),
        SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [Expanded(child: Text('الإجمالي: ${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), FilledButton.icon(onPressed: _checkout, icon: const Icon(Icons.check), label: const Text('تأكيد الطلب'))]))) ]);
    });
  }
  void _showProfile() {
    final user = ref.read(currentUserProvider) ?? {};
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('حسابي'), content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('الاسم: ${user['name'] ?? '-'}'), Text('البريد: ${user['email'] ?? '-'}'), Text('الصلاحية: ${user['role'] ?? 'user'}')]), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))]));
  }
}
