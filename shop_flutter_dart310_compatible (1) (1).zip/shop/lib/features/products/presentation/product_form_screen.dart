import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../data/product_repository.dart';
import '../model/product_model.dart';

class ProductFormScreen extends ConsumerStatefulWidget {
  const ProductFormScreen({super.key, this.product});
  final Product? product;
  @override ConsumerState<ProductFormScreen> createState() => _ProductFormScreenState();
}
class _ProductFormScreenState extends ConsumerState<ProductFormScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name, _description, _price, _stock, _category;
  String? _imagePath; bool _busy = false;
  @override void initState() { super.initState(); final p = widget.product; _name = TextEditingController(text: p?.name ?? ''); _description = TextEditingController(text: p?.description ?? ''); _price = TextEditingController(text: p?.price.toString() ?? ''); _stock = TextEditingController(text: p?.stock.toString() ?? ''); _category = TextEditingController(text: p?.category ?? ''); }
  Future<void> _pickImage() async { final file = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85); if (file != null) setState(() => _imagePath = file.path); }
  Future<void> _save() async {
    if (!_form.currentState!.validate()) return; setState(() => _busy = true);
    try {
      final repo = ref.read(productRepositoryProvider);
      final p = widget.product;
      if (p == null) { await repo.createProduct(name: _name.text.trim(), description: _description.text.trim(), price: _price.text.trim(), stock: _stock.text.trim(), category: _category.text.trim(), imagePath: _imagePath); }
      else { await repo.updateProduct(p.id, name: _name.text.trim(), description: _description.text.trim(), price: _price.text.trim(), stock: _stock.text.trim(), category: _category.text.trim(), imagePath: _imagePath); }
      if (mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  @override void dispose() { _name.dispose(); _description.dispose(); _price.dispose(); _stock.dispose(); _category.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.product == null ? 'إضافة منتج' : 'تعديل المنتج')),
    body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 600), child: Form(key: _form, child: ListView(padding: const EdgeInsets.all(20), children: [
      _field(_name, 'اسم المنتج'), const SizedBox(height: 12), _field(_description, 'الوصف', isRequired: false, maxLines: 3), const SizedBox(height: 12),
      _field(_price, 'السعر', numeric: true), const SizedBox(height: 12), _field(_stock, 'المخزون', numeric: true, integer: true), const SizedBox(height: 12), _field(_category, 'التصنيف'), const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.image), label: Text(_imagePath == null ? 'اختيار صورة للمنتج' : 'تم اختيار صورة')),
      if (widget.product?.image != null && _imagePath == null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('الصورة الحالية: ${widget.product!.image}')),
      const SizedBox(height: 20), FilledButton(onPressed: _busy ? null : _save, child: _busy ? const CircularProgressIndicator() : const Text('حفظ')),
    ])))),
  );
  Widget _field(TextEditingController c, String label, {bool isRequired = true, bool numeric = false, bool integer = false, int maxLines = 1}) => TextFormField(controller: c, maxLines: maxLines, keyboardType: numeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()), validator: (v) { if (isRequired && (v == null || v.trim().isEmpty)) return '$label مطلوب'; if (numeric && v != null && v.isNotEmpty && double.tryParse(v) == null) return 'أدخل رقماً صحيحاً'; if (integer && v != null && int.tryParse(v) == null) return 'أدخل عدداً صحيحاً'; if (numeric && v != null && double.tryParse(v) != null && double.parse(v) < 0) return 'لا يمكن أن تكون القيمة سالبة'; return null; });
}
