class Product {
  final int id;
  final String name;
  final String? description;
  final double price;
  final int stock;
  final String category;
  final String? image;
  Product({required this.id, required this.name, this.description, required this.price, required this.stock, required this.category, this.image});
  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: int.parse(json['id'].toString()), name: json['name']?.toString() ?? '',
    description: json['description']?.toString(), price: double.tryParse((json['price'] ?? 0).toString()) ?? 0,
    stock: int.tryParse((json['stock'] ?? 0).toString()) ?? 0,
    category: json['category']?.toString() ?? '', image: json['image']?.toString(),
  );
}
